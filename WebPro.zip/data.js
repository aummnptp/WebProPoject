const products = [
  {
    id: 1,
    name: "ผัดกระเพรา",
    des: "อร่อยๆ อื้มๆ",
    price: 50,
    is_favorite: false,
    image:
      "https://img.wongnai.com/p/1920x0/2020/09/01/67ba09fcb72845bc81fd413036e3f4eb.jpg",
    quantity: 0,
    stock: 0,
  },
  {
    id: 2,
    name: "เตี๋ยวต้มยำ",
    des: "อร่อยๆ อื้มๆ",
    price: 45,
    is_favorite: false,
    image:
      "https://i.pinimg.com/originals/d3/fc/7f/d3fc7f8f6a21cec93cb57dd66632be1b.jpg",
    quantity: 0,
    stock: 0,
  },
  {
    id: 3,
    name: "ผัดซีอิ๋ว",
    des: "อร่อยๆ อื้มๆ",
    price: 40,
    is_favorite: false,
    image:
      "https://i.ytimg.com/vi/EUrpZKegSiY/maxresdefault.jpg",
    quantity: 0,
    stock: 0,
  },
  {
    id: 4,
    name: "ข้าวไข่เจียว",
    des: "อร่อยๆ อื้มๆ",
    price: 35,
    is_favorite: false,
    image:
      "http://f.ptcdn.info/689/035/000/1442885991-imagejpeg-o.jpg",
    quantity: 0,
    stock: 0,
  },
  {
    id: 5,
    name: "ผัดไทย",
    des: "อร่อยๆ อื้มๆ",
    price: 45,
    is_favorite: false,
    image:
      "https://img.kapook.com/u/2015/surauch/cook2/PT1.jpg",
    quantity: 0,
    stock: 0,
  },
  {
    id: 6,
    name: "สเต๊ก",
    des: "อร่อยๆ อื้มๆ",
    price: 65,
    is_favorite: false,
    image:
      "https://www.gourmetandcuisine.com/Images/going_out/scoop/scoop_170detail.jpg",
    quantity: 0,
    stock: 0,
  },
  {
    id: 7,
    name: "ต้มยำ",
    des: "อร่อยๆ อื้มๆ",
    price: 55,
    is_favorite: false,
    image:
      "https://images.deliveryhero.io/image/foodpanda/recipes/tom-yum-goong.jpg",
    quantity: 0,
    stock: 0,
  },
  {
    id: 8,
    name: "โกโก้",
    des: "อร่อยๆ อื้มๆ",
    price: 40,
    is_favorite: false,
    image:
      " https://inwfile.com/s-ga/ymt6oc.jpg",
    quantity: 0,
    stock: 0,
  },
  {
    id: 9,
    name: "ข้าวขาหมู",
    des: "อร่อยๆ อื้มๆ",
    price: 45,
    is_favorite: false,
    image:
      "https://www.thipkitchen.com/images/course/khamu/img1.jpg",
    quantity: 0,
    stock: 0,
  },


];
